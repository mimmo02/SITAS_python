#Hauptprogramm: 
MainWindow.py

#Sensoren
sensor_left_lower_dry
sensor_left_middle_dry
sensor_left_upper_dry
sensor_right_lower_dry
sensor_right_middle_dry
sensor_right_upper_dry

sensor_left_lower_wet
sensor_left_middle_wet
sensor_left_upper_wet
sensor_right_lower_wet
sensor_right_middle_wet
sensor_right_upper_wet

#Ventile
ventile["LEFT_LOWER"]
ventile["LEFT_UPPER"] 
ventile["RIGHT_LOWER"] 
ventile["RIGHT_UPPER"]
ventile["MIDDLE"] 

#Lampen
lampen["LEFT_LOWER"] 
lampen["LEFT_UPPER"]
lampen["RIGHT_LOWER"]
lampen["RIGHT_UPPER"]

#Pumpe
Pumpe